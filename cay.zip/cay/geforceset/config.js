/*

 * Base By Anggazyy
 * Jangan hapus credit yaw

 DEV ? CAYWZZ
 HELPER ? XIN9 (DEV XINBOT)
 
*/

global.owner = [
  "6288804148639", //ganti nomor owner
  "" //nomor owner kedua kalo ada
]
global.nomorbot = '6287875411618' // nomor bot nya
global.idsaluran = "120363357312070270@newsletter"
global.idch = "120363357312070270@newsletter"
global.testi = "https://whatsapp.com/channel/0029Vau1badL7UVPMi0WMk0A"
global.saluran = 'https://whatsapp.com/channel/0029Vau1badL7UVPMi0WMk0A'
global.gc = 'https://whatsapp.com/channel/0029Vau1badL7UVPMi0WMk0A'
global.group = 't.me/caywzzneh'
global.namastore = "caywzz marketplace"
global.namaowner = "CaywZz"
// nama owner

global.namabot = "CaywzzV2.1"
//nama bot

global.namabot2 = "CaywzzAja"

global.version = "V2.1"
//========== Setting Foto ===========//
global.imgreply = "https://files.catbox.moe/6cfy4k.jpg"
global.thumb = "https://files.catbox.moe/6cfy4k.jpg"
global.thumb2 = "https://files.catbox.moe/6cfy4k.jpg"
global.thumb3 = "https://files.catbox.moe/6cfy4k.jpg"
global.thumb4 = "https://files.catbox.moe/6cfy4k.jpg"
//==setting sever private==//
global.domainn = "-"
global.apikeyy = "-"
global.capikeyy = "-"

//========== Setting Panell ==========//
global.egg = '15' // id eggs yang dipakai kalo id nya 5 biarin aja ini jangan di ubah
global.loc = '1' // id location
global.crown = "2823" // jangan di ubah
global.limitawal = 5

global.domain = '-' // Isi Domain Lu
global.apikey = '-' // Isi Apikey Plta Lu
global.capikey = '-' // Isi Apikey Pltc Lu

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
